#include "pch.h"
#include "CppUnitTest.h"
#include "..\OPI\CountingChips.h"
#include "..\OPI\CountingChips_Restart.h"
#include "..\OPI\CheckInputData.h"
#include "..\OPI\main.cpp"
#include <sstream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest
{
	TEST_CLASS(UnitTest)
	{
	public:
			//Module testing(Quantity: 25):
			
			//These first to fourth tests calculate numbers using a specific algorithm.
			TEST_METHOD(CountingChips_1)
			{
				Assert::AreEqual(CountingChips(1, 1, 1), 1);
			}
			TEST_METHOD(CountingChips_2)
			{
				Assert::AreEqual(CountingChips(3, 4, 2), 9);
			}
			TEST_METHOD(CountingChips_3)
			{
				Assert::AreEqual(CountingChips(3, 10, 4), 15);
			}
			TEST_METHOD(CountingChips_4)
			{
				Assert::AreEqual(CountingChips(10, 10, 10), 100);
			}

			
			//These first to second tests return a boolean value on input one or two.
			TEST_METHOD(CountingChips_Restart_1)
			{
				stringstream input("1");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(CountingChips_Restart(), true);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(CountingChips_Restart_2)
			{
				stringstream input("2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(CountingChips_Restart(), false);
				cin.rdbuf(oldCin);
			}
			//These third to fourth tests, if you enter any data other than one or two, 
			//then the loop will call itself until one or two is entered.
			TEST_METHOD(CountingChips_Restart_3)
			{
				stringstream input("5\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(CountingChips_Restart(), false);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(CountingChips_Restart_4)
			{
				stringstream input("8\n�\n1");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(CountingChips_Restart(), true);
				cin.rdbuf(oldCin);
			}

			//testing the InputData function
			//These first to second tests initialize the variables.
			TEST_METHOD(CheckInputData_1)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("2\n5\n10");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				Assert::AreEqual(NumberOfPlayers, 2);
				Assert::AreEqual(PlayerMaxLevel, 5);
				Assert::AreEqual(RedChipsMaxLevel, 10);
				Assert::AreEqual(InputDataSuccessfully, true);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(CheckInputData_2)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("3\n4\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				Assert::AreEqual(NumberOfPlayers, 3);
				Assert::AreEqual(PlayerMaxLevel, 4);
				Assert::AreEqual(RedChipsMaxLevel, 2);
				Assert::AreEqual(InputDataSuccessfully, true);
				cin.rdbuf(oldCin);
			}
			//This is testing threeth through fiveth, if you enter any data that does not meet the conditions,
			//then the module will ask the user whether he wants to start again (enter one) or not (enter two),
			//if you enter another data, that is, not one or two,
			//then the module again will ask the user if he wants to start over.
			//In this testing, the user agrees and enters correct data.
			TEST_METHOD(CheckInputData_3)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("l\n1\n2\n2\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				Assert::AreEqual(NumberOfPlayers, 2);
				Assert::AreEqual(PlayerMaxLevel, 2);
				Assert::AreEqual(RedChipsMaxLevel, 2);
				Assert::AreEqual(InputDataSuccessfully, true);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(CheckInputData_4)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("2\no\n1\n2\n2\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				Assert::AreEqual(NumberOfPlayers, 2);
				Assert::AreEqual(PlayerMaxLevel, 2);
				Assert::AreEqual(RedChipsMaxLevel, 2);
				Assert::AreEqual(InputDataSuccessfully, true);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(CheckInputData_5)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("2\n2\np\n1\n2\n2\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				Assert::AreEqual(NumberOfPlayers, 2);
				Assert::AreEqual(PlayerMaxLevel, 2);
				Assert::AreEqual(RedChipsMaxLevel, 2);
				Assert::AreEqual(InputDataSuccessfully, true);
				cin.rdbuf(oldCin);
			}
			
			//This is testing sixth through seventh does not return anything and does not initialize anything,
			//so if testing does not complete, then the test fails,
			//if testing completes, then the test passes.
			
			TEST_METHOD(CheckInputData_6)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("0\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(CheckInputData_7)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("0\nk\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				cin.rdbuf(oldCin);
			}
			//testing the CheckInputData function
			//Testing from the eighth to the twelfth, 
			//checks the number entered at the beginning, 
			//if the number is not a positive integer, then zero is returned, 
			//otherwise it returns the entered number.
			TEST_METHOD(CheckInputData_8)
			{
				string Data = "5";
				Assert::AreEqual(CheckInputData(Data), 5);
			}
			TEST_METHOD(CheckInputData_9)
			{
				string Data = "-8";
				Assert::AreEqual(CheckInputData(Data), 0);
			}
			TEST_METHOD(CheckInputData_10)
			{
				string Data = "h";
				Assert::AreEqual(CheckInputData(Data), 0);
			}
			TEST_METHOD(CheckInputData_11)
			{
				string Data = "54";
				Assert::AreEqual(CheckInputData(Data), 54);
			}
			TEST_METHOD(CheckInputData_12)
			{
				string Data = "7t";
				Assert::AreEqual(CheckInputData(Data), 0);
			}
			//testing the CheckInputData function
			//Testing from thirteenth to fifteenth, 
			//does not return anything and does not initialize anything
			TEST_METHOD(CheckInputData_13)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData_Restart(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(CheckInputData_14)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("5\nj\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData_Restart(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(CheckInputData_15)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("1\n2\nh\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				cin.rdbuf(oldCin);
			}
			//Sixteenth testing, the user agrees to re-enter data and enters it correctly, 
			// after which the variables are initialized
			TEST_METHOD(CheckInputData_16)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("1\n2\n5\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				Assert::AreEqual(NumberOfPlayers, 2);
				Assert::AreEqual(PlayerMaxLevel, 5);
				Assert::AreEqual(RedChipsMaxLevel, 2);
				Assert::AreEqual(InputDataSuccessfully, true);
				cin.rdbuf(oldCin);
			}
			// Seventeenth testing, the user agrees to re-enter data and enters incorrect data, 
			// the program asks the user to re-count, but he rejects.
			TEST_METHOD(CheckInputData_17)
			{
				int NumberOfPlayers, RedChipsMaxLevel, PlayerMaxLevel;
				bool InputDataSuccessfully;
				stringstream input("1\n2\nk\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				InputData(NumberOfPlayers, PlayerMaxLevel, RedChipsMaxLevel, InputDataSuccessfully);
				cin.rdbuf(oldCin);
			}

		
			//Testing the main file(Quantity: 5):
			//This is testing, the user entered the correct data,
			//the program calculated using a certain algorithm,
			//the program asks the user if another calculation is required, the user rejects.
			TEST_METHOD(main_1)
			{
				stringstream input("8\n5\n1\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(main(), 0);
				cin.rdbuf(oldCin);
			}
			/*
			This is testing, the user entered the correct data,
			the program calculated using a certain algorithm,
			the program asks the user if another calculation is required,
			the user accepts the request, after the operation,
			the program asks again, but the user rejects.
			*/
			TEST_METHOD(main_2)
			{
				stringstream input("2\n2\n2\n1\n5\n6\n7]\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(main(), 0);
				cin.rdbuf(oldCin);
			}
			//These tests from the third to the fifth, the user entered the data incorrectly and rejected the request to re-enter the data.
			TEST_METHOD(main_3)
			{
				stringstream input("h\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(main(), 0);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(main_4)
			{
				stringstream input("5\nh\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(main(), 0);
				cin.rdbuf(oldCin);
			}
			TEST_METHOD(main_5)
			{
				stringstream input("y\nh\n2");
				streambuf* oldCin = cin.rdbuf();
				cin.rdbuf(input.rdbuf());
				Assert::AreEqual(main(), 0);
				cin.rdbuf(oldCin);
			}
	};
}
